declare from_date, to_date date;
declare from_utc, to_utc timestamp;

set from_date = '2025-07-01'; 
set to_date = '2025-07-30';

set from_utc = timestamp_sub(timestamp(from_date), interval 9 hour);
set to_utc = timestamp_sub(timestamp(date_add(to_date, interval 1 day)), interval 9 hour);

-- 요청서 시작
with start_req as (
select sr.amplitude_id 
  , sr.device_id
  , sr.platform
  , sr.user_id
  , sr.library
  , timestamp_add(sr.event_time, interval 9 hour) as event_time
  , sr.event_type as event_name
  , concat(json_extract_scalar(sr.user_properties, '$.utm_source'), '/', json_extract_scalar(sr.user_properties, '$.utm_medium')) as concat_utm
from `soomgo-159006.amplitude_prod.EVENTS_195859` as sr 
where 1=1
  and sr.event_time between from_utc and to_utc 
  and sr.platform in ('Web', 'Android', 'iOS')
  and sr.event_type = 'Start Request Form'
  -- and sr.library in ('segment', 'amplitude-js/5.2.2')
)

-- 마케팅 미관리 utm(5개) 정보
, raw1 as (
  select sr.*
        -- organic / paid
        , case when concat_utm = 'kakao_allim_talk/deeplink' then 'organic'
                when concat_utm = 'kakao/-' then 'organic'
                when concat_utm = 'crm/apppush' then 'organic'
                when concat_utm = 'crm/iosinapp-aosinapp-webinapp' then 'organic'
                when concat_utm = 'kakao/kakaotalk_bizmessage' then 'paid'
          end as type1      
  from start_req as sr
  where 1=1
  and concat_utm in ('kakao_allim_talk/deeplink','kakao/-','kakao/kakaotalk_bizmessage','crm/apppush','crm/iosinapp-aosinapp-webinapp')
)

-- 기존 map_utm_channel 테이블 내 utm 정보
, raw2 as (
  select sr.*
        -- organic / paid
        , case when channel_name is null then 'organic' 
                when channel_name = 'performance' then 'paid'
                else 'organic' end as type1
        , channel_name
  from start_req as sr
  left join `dm_phase_2_mkt.map_utm_channel` as m on sr.concat_utm = m.concat_utm
  where 1=1
  and sr.concat_utm not in ('kakao_allim_talk/deeplink','kakao/-','kakao/kakaotalk_bizmessage','crm/apppush','crm/iosinapp-aosinapp-webinapp')
)

-- utm 정보 하나의 테이블로 합치기
, base as (
  select  *
          , 'etc' channel_name
  from raw1
  union all
  select  *
  from raw2
)

-- select count(1) from base
select type1
  , channel_name
  , count(1) as cnt_volume
  , count(distinct amplitude_id) as cnt_amplitudeID
  , count(distinct device_id) as cnt_deviceID
from base 
group by 1 , 2
order by 1 , 2