-- 견적서 : Paid_Organic
declare from_date, to_date date;
declare from_utc, to_utc timestamp;

set from_date = '2025-07-01'; 
set to_date = '2025-07-30';

set from_utc = timestamp_sub(timestamp(from_date), interval 9 hour);
set to_utc = timestamp_sub(timestamp(date_add(to_date, interval 1 day)), interval 9 hour);

-- 요청서 시작
with start_request as (
select sr.amplitude_id 
  , sr.device_id
  , sr.platform
  , sr.user_id
  , timestamp_add(sr.event_time, interval 9 hour) as event_time
  , sr.event_type as event_name
  , concat(json_extract_scalar(sr.user_properties, '$.utm_source'), '/', json_extract_scalar(sr.user_properties, '$.utm_medium')) as concat_utm
from `soomgo-159006.amplitude_prod.EVENTS_195859` as sr 
where 1=1
  and sr.event_time between from_utc and to_utc 
  and sr.platform in ('Web', 'Android', 'iOS')
  and sr.event_type = 'Start Request Form'
)

-- UTM 매핑
, start_request_utm as (
select sr.*
  , case when sr.concat_utm in ('kakao_allim_talk/deeplink', 'kakao/-', 'crm/apppush', 'crm/iosinapp-aosinapp-webinapp') then 'organic'
        when sr.concat_utm = 'kakao/kakaotalk_bizmessage' then 'paid'
        when m.channel_name is null then 'organic'
        when m.channel_name = 'performance' then 'paid'
        else 'organic' 
    end as type1
  , case when sr.concat_utm in ('kakao_allim_talk/deeplink', 'kakao/-', 'crm/apppush', 'crm/iosinapp-aosinapp-webinapp') then 'etc'
        when sr.concat_utm = 'kakao/kakaotalk_bizmessage' then 'etc'
        else m.channel_name
    end as channel_name
from start_request sr
left join `dm_phase_2_mkt.map_utm_channel` as m on sr.concat_utm = m.concat_utm
)

-- select count(1) from base
select type1
  , channel_name
  , count(1) as cnt_volume
  , count(distinct amplitude_id) as cnt_amplitudeID
  , count(distinct device_id) as cnt_deviceID
from start_request_utm 
group by 1, 2
order by 1, 2